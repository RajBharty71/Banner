<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Banner extends CI_Controller {


	public function index()
	{
      $this->load->view('Banner_view');
	}

    public function banner_list(){
        $result = $this->db->get('banner')->result_array();
	    $status =  !empty($result) ? true:false;
		$resonse = array('status' => $status,'data' => $result);
		echo json_encode($resonse);
	}

}
