// for call APi I use pure JS 

// i use setInterval for check new banner .Yes we can also use websocket  for this.

async function getData() {
    const url = "http://localhost/banner/index.php/banner/banner_list";
    try {
      const response = await fetch(url,{method: "GET"});
      if (!response.ok) {
        throw new Error(`Response status: ${response.status}`);
      }
      const json = await response.json();
      let html = '';  
       if(json.status == true){
        json.data.forEach(function(url) {
            html += `<div class="banner"><img src="${url.url}" alt="${url.id}" title = "copy URL"></div>`;
        });
         let bannerHeadElement = document.querySelector(".banner-container");
         bannerHeadElement.innerHTML = html;
       }else{
        alert("Something went wrong");
       }
    
       
       
    } catch (error) {
      console.error(error.message);
    }
  }
  document.addEventListener("click", function(event) {
    if (event.target.closest(".banner")) {
       let bannerURL =  event.target.getAttribute('src');
       if (bannerURL) {
         navigator.clipboard.writeText(bannerURL)
        .then(() => {
            alert("Copied: " + bannerURL);
        })
        .catch(err => {
            console.error("Failed to copy: ", err);
        });
    } else {
        alert("No attribute found!");
    }
    }
});
getData(); //first time call

setInterval(function(){  // evey 10 sec after  webpage refresh  
    getData();
},10000);



   


 